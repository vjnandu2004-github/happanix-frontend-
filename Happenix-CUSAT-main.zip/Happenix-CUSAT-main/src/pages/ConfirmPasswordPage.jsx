import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import logo from '../assets/logo-h.png';
import '../styles/AuthForm.css';

function ConfirmPasswordPage() {
    const navigate = useNavigate();
    const [formData, setFormData] = useState({
        code: '',
        newPassword: '',
        confirmPassword: ''
    });
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState('');

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError('');

        if (formData.newPassword !== formData.confirmPassword) {
            setError("Passwords do not match.");
            return;
        }

        setIsLoading(true);
        console.log("Resetting password with code:", formData.code);
        await new Promise(resolve => setTimeout(resolve, 1500));
        setIsLoading(false);
        
        alert("Password has been reset successfully!");
        navigate('/login');
    };

    return (
        <div className="auth-page">
            <div className="auth-form-container">
                <img src={logo} alt="Happenix Logo" className="auth-logo" />
                <h2 style={{ textTransform: 'lowercase', fontSize: '2.2rem' }}>confirm password</h2>
                
                {error && <p style={{ color: '#F56565', marginTop: '1.5rem', marginBottom: 0 }}>{error}</p>}

                <form onSubmit={handleSubmit} className="auth-form" style={{ marginTop: '2.5rem' }}>
                    <div className="input-group">
                        <input
                            type="text"
                            name="code"
                            value={formData.code}
                            onChange={handleChange}
                            placeholder="Enter the code from your E-mail"
                            required
                        />
                    </div>
                    <div className="input-group">
                        <input
                            type="password"
                            name="newPassword"
                            value={formData.newPassword}
                            onChange={handleChange}
                            placeholder="enter password"
                            required
                        />
                    </div>
                    <div className="input-group">
                        <input
                            type="password"
                            name="confirmPassword"
                            value={formData.confirmPassword}
                            onChange={handleChange}
                            placeholder="confirm password"
                            required
                        />
                    </div>
                    
                    <button type="submit" className="auth-button" disabled={isLoading}>
                        {isLoading ? 'Resetting...' : 'Reset Password'}
                    </button>
                </form>

                <p className="auth-switch-link">
                    <Link to="/login">Back to login</Link>
                </p>
            </div>
        </div>
    );
}

export default ConfirmPasswordPage;