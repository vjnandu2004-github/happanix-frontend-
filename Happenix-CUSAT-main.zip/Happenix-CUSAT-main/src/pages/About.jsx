function About() {
  return (
    <div style={{ padding: "2rem" }}>
      <h1>About HAPPENIX</h1>
      <p>
        Happenix is a cloud-based event management system built by students of
        CUSAT.
      </p>
    </div>
  );
}

export default About;
