import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import logo from '../assets/logo-h.png';
import '../styles/AuthForm.css';

function ConfirmAccountPage() {
    const navigate = useNavigate();
    const [otp, setOtp] = useState('');
    const [isLoading, setIsLoading] = useState(false);

    const handleSubmit = async (e) => {
        e.preventDefault();
        setIsLoading(true);
        console.log("Verifying account with OTP:", otp);
        await new Promise(resolve => setTimeout(resolve, 1500));
        setIsLoading(false);
        
        alert("Account confirmed successfully! Please sign in.");
        navigate('/login');
    };

    const handleResend = () => {
        alert("A new confirmation code has been sent to your email.");
    };

    return (
        <div className="auth-page">
            <div className="auth-form-container">
                <img src={logo} alt="Happenix Logo" className="auth-logo" />
                <h2>Confirm Your Account</h2>
                <p>Enter the 6-digit code we sent to your email address.</p>
                
                <form onSubmit={handleSubmit} className="auth-form">
                    <div className="input-group">
                        <input
                            type="text"
                            name="otp"
                            value={otp}
                            onChange={(e) => setOtp(e.target.value)}
                            placeholder="Enter OTP"
                            required
                        />
                    </div>
                    
                    <button type="submit" className="auth-button" disabled={isLoading}>
                        {isLoading ? 'Verifying...' : 'Verify Account'}
                    </button>
                </form>

                <p className="auth-switch-link">
                    Didn't receive a code?{' '}
                    <button onClick={handleResend} style={{ background: 'none', border: 'none', color: '#63B3ED', cursor: 'pointer', padding: 0 }}>
                        Resend
                    </button>
                </p>
                <p className="auth-switch-link" style={{ marginTop: '0.5rem' }}>
                    <Link to="/login">Back to login</Link>
                </p>
            </div>
        </div>
    );
}

export default ConfirmAccountPage;